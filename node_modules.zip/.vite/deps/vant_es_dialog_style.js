import "./chunk-WMQKQWMR.js";
//# sourceMappingURL=vant_es_dialog_style.js.map
