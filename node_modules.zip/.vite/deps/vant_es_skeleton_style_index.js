// node_modules/vant/es/skeleton/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/skeleton-title/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/skeleton-avatar/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/skeleton-paragraph/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/skeleton/index.css";
//# sourceMappingURL=vant_es_skeleton_style_index.js.map
