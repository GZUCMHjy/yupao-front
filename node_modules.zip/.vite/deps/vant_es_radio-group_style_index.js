// node_modules/vant/es/radio-group/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/radio-group/index.css";
//# sourceMappingURL=vant_es_radio-group_style_index.js.map
