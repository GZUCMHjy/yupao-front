// node_modules/vant/es/cell-group/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/cell-group/index.css";
//# sourceMappingURL=vant_es_cell-group_style_index.js.map
