// node_modules/vant/es/button/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/badge/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/icon/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/loading/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/button/index.css";
//# sourceMappingURL=vant_es_button_style_index.js.map
