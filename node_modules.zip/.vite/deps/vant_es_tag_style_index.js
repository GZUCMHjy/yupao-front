// node_modules/vant/es/tag/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/badge/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/icon/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/tag/index.css";
//# sourceMappingURL=vant_es_tag_style_index.js.map
