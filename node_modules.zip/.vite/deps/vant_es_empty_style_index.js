// node_modules/vant/es/empty/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/empty/index.css";
//# sourceMappingURL=vant_es_empty_style_index.js.map
