// node_modules/vant/es/field/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/badge/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/icon/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/cell/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/field/index.css";
//# sourceMappingURL=vant_es_field_style_index.js.map
