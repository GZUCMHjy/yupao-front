// node_modules/vant/es/tabs/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/sticky/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/swipe/index.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/tabs/index.css";
//# sourceMappingURL=vant_es_tabs_style_index.js.map
