// node_modules/vant/es/tabbar/style/index.mjs
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/style/base.css";
import "D:/LouisProject/星球项目/yupao-frontend/node_modules/vant/es/tabbar/index.css";
//# sourceMappingURL=vant_es_tabbar_style_index.js.map
