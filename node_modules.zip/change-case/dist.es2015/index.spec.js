import * as changeCase from ".";
describe("change case", function () {
    it("exports expected methods", function () {
        expect(typeof changeCase).toEqual("object");
    });
});
//# sourceMappingURL=index.spec.js.map