module.exports = require('./binary-extensions.json');
