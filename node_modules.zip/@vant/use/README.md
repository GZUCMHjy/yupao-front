# Vant Use

Built-in composition APIs of Vant.

## Install

```shell
# with npm
npm i @vant/use

# with yarn
yarn add @vant/use

# with pnpm
pnpm add @vant/use

# with Bun
bun add @vant/use
```
