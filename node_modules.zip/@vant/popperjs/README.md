# @vant/popperjs

@popperjs/core in commonjs format, added Object.assign polyfill.

## Install

```shell
# with npm
npm i @vant/popperjs

# with yarn
yarn add @vant/popperjs

# with pnpm
pnpm add @vant/popperjs
```

## Usage

see: https://popper.js.org/

## Refer

issue: https://github.com/vant-ui/vant/issues/7626
