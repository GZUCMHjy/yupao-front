import type { AppRecord } from './api.js';
export interface Context {
    currentTab: string;
    currentAppRecord: AppRecord;
}
